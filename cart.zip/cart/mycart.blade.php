<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <td>Product</td>
            <td>Quanitity</td>
            <td>Total Amt</td>
        </tr>
        @php($total=0)
        @foreach($Prod_data as $p)
        @foreach($data as $d=>$v)
        @if(is_numeric($d))
        @if($v['id']==$p->Id)
        <tr>
            <td><img src="" alt=""></td>
            <h2>{{$p->Name}}</h2>
            <h2>{{'Rs.'.$p->Price}}</h2>
            </td>
        <td>
            <form action="reorder" method="post">
                @csrf
                
                <td><input type="submit" name="Change_qty" value="-"></td>
                <td><input type="hidden" name="txtID" value="{{p->Id}}"></td>
                <td><input type="hidden" name="avail_qty" value="{{p>Qua}}"></td>
                <td><input type="text" name="qty" value="{{$v['Qua']}}"></td>
                <td><input type="submit" name="Change_qty" value="+"></td>
            </form>
        </td>
        <td>
            <h2>{{'Rs.'.$v['qty']*$p->Price}}</h2>
            @php($total=$total +($v['qty']*$p->Price))
        </td>
        </tr>
        @endif
        @endif
        @endforeach
        @endforeach
    </table>
</body>
</html>