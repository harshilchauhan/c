<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ShoppingController extends Controller
{
    //
    function loadShopping()
    {
        $data=DB::table('items')->get();
        return view('shopping',['Data'=>$data]);
    }
    function manage_cart(Request $req){
        //echo "in method";
        $item=array('id'=>$req->txtID,'qty'=>$req->ordqty);
        $data=session()->all();
        $flag=0;
        foreach($data as $d=>$v)
        {
            if(is_numeric($d))
            {
                if($req->txtID==$v['id'])
                {
                    echo"<script>alert('product already exists')</script>";
                    $flag=1;
                    break;
                }
            }
        }
        if($flag==0)
        {
            session()->put($req->txtID,$item);
        }
        return redirect('loadShopping');
    }

    function mycart()
    {
        $data=session()->all();
        $item=array();
        foreach($data as $d=>$v)
        {
            if(is_numeric($d))
            {
                array_push($item,$v['id']);
            }
        }
        $prod=DB::table('items')->whereIn('Id',$item)->get();
        return view('mycart',['Prod_data'=>$prod]);
    }
    function reorder(Request $req)
    {
        if($req->Change_qty=='-')
        {
            $q=$req->Qua-1;
            $data=sessin()->all();
            if($q>0)
            {
                foreach($data as $d=>$v)
                {
                    if(is_numeric($d))
                    {
                        if($v['id']==$req->txtID)
                        {
                            $temp=array('id'=>$v['id'],'Qua'=>$q);
                            session()->pull($d);
                            session()->put($d,$temp);
                        }
                    }
                }
            }
            else{
                foreach($data as $d=>$v) 
                {
                    if(is_numeric($d))
                    {
                        if($v['id']==$req->txtID)
                        {
                            session()->pull($d);
                        }
                    }
                }
            }
            return redirect('mycart');
        }
        if($req->Change_qty=='+')
        {
            $q=$req->Qua+1;
            $data=sessin()->all();
            if($q<=$req->avail_qty)
            {
                foreach($data as $d=>$v)
                {
                    if(is_numeric($d))
                    {
                        if($v['id']==$req->txtID)
                        {
                            $temp=array('id'=>$v['id'],'qua'=>$q);
                            session()->pull($d);
                            session()->put($d,$temp);
                        }
                    }
                }
            }
            else{
                echo"<script>alert('qty is more than available qty')</script>";
            }
            return redirect('mycart');
        }
    }
}
