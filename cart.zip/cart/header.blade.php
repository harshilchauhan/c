<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
@php($data=session()->all())
@php($c=0)
@foreach($data as $d=>$v)
@if(is_numeric($d))
@php($c=$c+1)
@endif
@endforeach
<h1>Shopping Cart</h1>
<p>
    <h1><a href="home">Home</a></h1>
    <h1><a href="loadShopping">Purchase Item</a></h1>

    <h1><a href="mycart">My Cart @if($c>0){{$c}}@endif</a></h1>

</p>
</body>
</html>