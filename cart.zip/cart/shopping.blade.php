<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<x-header/>
    <form action="manage_cart" method="post">
        @csrf
        <table>
            @isset($Data)
            @foreach($Data as $d)
            <tr>
        <td><input type="text" value="{{$d->Name}}"></td>
        <td><input type="text" value="{{$d->Price}}"></td>


        <td><input type="hidden" name="txtID" value="{{$d->Id}}">
        <input type="number" name="ordqty" min="1" max="{{$d->Qua}}">
        <input type="submit" name="manage_cart" value="add_to_cart"></td>
    </tr>
        @endforeach
        @endisset
        </table>
    </form>
</body>
</html>